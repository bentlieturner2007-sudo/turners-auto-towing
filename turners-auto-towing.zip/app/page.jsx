const CONFIG = {
  phone: "4356803551",
  displayPhone: "(435) 680-3551",
  googleMapsLink: "https://maps.app.goo.gl/rxeg8K8KjMEVxAvg7?g_st=ic",
  heroImage: "/images/mountain-truck.jpg",
  teamPhoto: "/images/team-photo.jpg"
};

export default function Page() {
  return (
    <main style={{fontFamily:"sans-serif"}}>
      <h1>Turner's Auto & Towing</h1>
      <p>24/7 Towing - Utah</p>
      <a href={`tel:${CONFIG.phone}`}>Call Now</a>
      <br/>
      <a href={CONFIG.googleMapsLink} target="_blank">Open Maps</a>
      <div>
        <h2>Team</h2>
        <img src={CONFIG.teamPhoto} width="400"/>
      </div>
    </main>
  );
}
